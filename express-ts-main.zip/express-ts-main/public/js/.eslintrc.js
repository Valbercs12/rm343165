module.exports = {
    extends: [
        "eslint:recommended",
    ],
    ignorePatterns: [
        ".eslintrc.js",
    ],
    env: {
        browser: true,
    }
}
